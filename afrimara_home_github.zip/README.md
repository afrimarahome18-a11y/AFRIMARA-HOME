# Afrimara Home Website

This is the **Afrimara Home** website — a tour guide company providing tours, accommodation, and security services.

---

## 🚀 How to View Locally
1. Download or clone this repository.
2. Open `index.html` in your web browser (Chrome, Firefox, etc.).

---

## 🌍 How to Publish on GitHub Pages
1. Make sure the file `index.html` is in the **root** of your repository (not inside a folder).
2. Go to **Settings → Pages** in your GitHub repository.
3. Under **Source**, select:
   - Branch: `main`
   - Folder: `/ (root)`
4. Click **Save**.
5. Wait 1–5 minutes. Your site will be live at:
   ```
   https://<your-username>.github.io/afrimara-home/
   ```

---

## 📂 Repository Structure
```
afrimara-home/
│
├── index.html    # Main website file
├── README.md     # Instructions
```

---

## ✅ Notes
- The website uses **Tailwind CSS via CDN**, so an internet connection is needed for the styles to load.
- To make it work fully offline, you’d need to download and include Tailwind locally.

---

**Enjoy your new website! 🌍**
